//
// Created by juntao, at wuhan university   on 2020/10/23.
//
#include "include/Utils/InnerLink/KvContainer.h"

/// containers here
std::map<std::string, std::string> bamboo::KvContainer::kvs;